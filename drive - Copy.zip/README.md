# Google Drive Uploader

Uses the `chrome.experimental.identity.getAuthToken()` API to perform OAuth2 and
access the Google Drive API.

To upload files: drag in files from the desktop onto the app.

## APIs

* [Identity](http://developer.chrome.com/trunk/apps/experimental.identity.html)